﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InternetBanking.Core.Application.ViewModels.Account
{
    public class TypeAccountViewModel
    {
        public int Id { get; set; }
        public string NameAccount { get; set; }

    }
}
