﻿
namespace InternetBanking.Core.Application.Enums
{
    public enum AccountTypes
    {
        SavingAccount = 1,
        CreditAccount,
        LoanAccount
    }
}
