﻿using InternetBanking.Infrastructure.Identity.Entities;


namespace InternetBanking.Core.Application.Interfaces.Repositories
{
    public interface ITypeAccountRepository :  IGenericRepository<TypeAccount>
    {

    }
}
